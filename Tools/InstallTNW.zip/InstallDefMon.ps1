# Installation Program for Defender Monitor subsystem
# Copyright 2022 TheNetWorks LLC

$TNW_HOME = "\TheNetWorks"
$UriRedist = "https://aka.ms/vs/17/release/vc_redist.x86.exe"
$UriDefMonZip = "https://img1.wsimg.com/blobby/go/03bcf8d9-e094-4891-a3c9-2e6de39bbcdc/downloads/DefenderMon.zip?ver=1649778693460"
$UriDefMonCfg = "https://img1.wsimg.com/blobby/go/03bcf8d9-e094-4891-a3c9-2e6de39bbcdc/downloads/DefenderStat.cfg.txt?ver=1649506485529"

cd \

if(-Not (Test-Path $TNW_HOME))
{
  mkdir $TNW_HOME
}
cd $TNW_HOME

# Get the Microsoft Redistributable
Invoke-WebRequest -Uri $UriRedist -OutFile $TNW_HOME\redistx86.exe
./redistx86.exe /Q /Passive

# Get the DefenderMon.exe (in a zip archive)
Invoke-WebRequest $UriDefMonZip -outfile DefenderMon.zip

# Extract the executable from the Archive
tar xvf DefenderMon.zip

# Get the default config file (which should be obtained every day
Invoke-WebRequest $UriDefMonCfg -outfile DefenderStat.cfg

# Cleanup
del $TNW_HOME\DefenderMon.zip
#Remove-Item $TNW_HOME\redistx86.exe -Force	# Doesn't work