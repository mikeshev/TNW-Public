# Install SNMP using PowerShell (admin shell)
# Must reboot the machine afterwards and set the community name. 
# This set the Inbound Firewall rule when tested 

Get-WindowsCapability -Name SNMP* -online | Select-Object -Property Name, State