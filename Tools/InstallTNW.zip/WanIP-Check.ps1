# PowerShell Script to get the current WAN IP and compare it with the previous value
# Uses the non-admin info@thenetworks.us email address to send email notification
# Copyright TheNetWorks LLC 2024

function SendMail ($Msg) {		# Send a message & subject line

  $MailServer="smtp.office365.com"
  $ToMail = "mike@thenetworks.us"
  
  # Get the Credentials
  $User = "info@thenetworks.us"		# Pick a non-admin user to just send mail
  $AppPW = "ypbhwycvjpnqxczv"

  $PWord=ConvertTo-SecureString -String $AppPW -AsPlainText -Force
  $Cred = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $User, $PWord

  # Now send the message
  Send-MailMessage -Body $Msg -From $User -SmtpServer $MailServer -Subject $Msg -Credential $Cred -To $ToMail -UseSsl -Port 587
}

# ----------------  Execution Starts Here ----------------
$WanIPLocation="C:/TheNetWorks/LastWanIP.txt"
$LastWanIP = "0.0.0.0"	# Set to some default for first run

# Get the Hostname
$HostName=$env:computername

$WanIP=(Invoke-RestMethod https://geolocation-db.com/json).IPv4

# Read the Last Wan IP from the persistant storage. Check to see if file exists (first run?)
if(Test-Path $WanIPLocation -PathType Leaf){
  $LastWanIP=Get-Content $WanIPLocation -Raw
}
else {
  $LastWanIP = $WanIP		# Make them equal so we don't get warning on 1st run
}

# Compare the two IP Addresses looking for a change
if($WanIP -ne $LastWanIP) {
  # They are different; this is where we send notification mail
  echo "WanIP Changed - sending email notification"

  # Set Subject & (short) Message
  $Msg = "$HostName-WAN IP Changed to $WanIP"
  SendMail $Msg
}

# Now write the current WanIP into the LastWanIP.txt file to remember
$WanIP | out-file -filepath $WanIPLocation -NoNewline