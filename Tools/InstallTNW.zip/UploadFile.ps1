# PowerShell Script to upload a file as an email attachment. This would have limitations
# in file sizes and types (should zip and binaries or executables)
# Uses the non-admin info@thenetworks.us email address to send email notification
# Copyright TheNetWorks LLC 2024

function SendMailAttachment ($FileName) {

  # Get the Hostname
  $HostName=$env:computername

  $MailServer="smtp.office365.com"
  $ToMail = "mike@thenetworks.us"
  
  # Get the Credentials
  $User = "info@thenetworks.us"		# Pick a non-admin user to just send mail
  $AppPW = "ypbhwycvjpnqxczv"

  # Set Subject & (short) Message
  $Msg = "File from: $HostName"

  $PWord=ConvertTo-SecureString -String $AppPW -AsPlainText -Force
  $Cred = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $User, $PWord

  # Now send the message
  Send-MailMessage -Body $Msg -From $User -SmtpServer $MailServer -Subject $Msg -Credential $Cred -To $ToMail -Attachments $FileName -UseSsl -Port 587
}

# ----------------  Execution Starts Here ----------------

# Get the filename from the command line
$FileName = $args[0]

# Verify that the file exists
if(Test-Path $FileName -PathType Leaf){
  SendMailAttachment $FileName
}
else {
  echo "File: $Filename not found"
}
