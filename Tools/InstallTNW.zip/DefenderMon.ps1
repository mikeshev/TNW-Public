# Copyright 2022 TheNetWorks LLC 
# Script to get a snapshot of the current versions on an updated machine

function Remove-BomFromFile ($OldPath, $NewPath)
{
  $Content = Get-Content $OldPath -Raw
  $Utf8NoBomEncoding = New-Object System.Text.UTF8Encoding $False
  [IO.File]::WriteAllLines($NewPath, $Content, $Utf8NoBomEncoding)
}

# Execution starts here --------------------------------------------------
$OrgFile = "\TheNetWorks\DefenderStatBOM.txt"
$OutFile = "\TheNetWorks\DefenderStat.txt"

# Set default encoding to UTF8
$PSDefaultParameterValues['Out-File:Encoding'] = 'utf8'

# Get the statistics and write to the file
Get-MpComputerStatus | Out-File $OrgFile -Encoding UTF8

Remove-BomFromFile -OldPath $OrgFile -NewPath $OutFile

del $OrgFile

# Now that we have gathered the statistics Parse them for compliance
./DefenderMon.exe $OutFile
