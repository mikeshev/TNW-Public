# TheNetWorks LLC - Pre Qualification script
# Copyright 2023 TheNetWorks LLC
# May need to set execution polciy prior to execution

# Set-ExecutionPolicy -Scope Process Unrestricted
Write-Output " ------ Set-ExecutionPolicy -Scope Process Unrestricted ------- "

# Checking basic Disk Health
Write-Output "----------Running chkdsk -----------"

# Make sure the disk itself is Sound
chkdsk /scan c:

Write-Output "---------- Getting Disk Health ----------"
Get-PhysicalDisk

# Make sure the Image is Sound
Write-Output "---------- Check Deployment Image ----------"
dism /online /cleanup-image /ScanHealth

Write-Output "--------- Running File System Checker ---------"
sfc /scannow

# Make sure updates have been happening
Write-Output "--------- Check for Windows Updates ---------"
get-wmiobject -class win32_quickfixengineering 

# Check Quarantine files
Write-Output "--------- Check for Quarantine Files ---------"
c:\"Program Files\Windows Defender"\MpCmdRun.exe -restore -listall

# Lastly check the Event Log for recent Critical Errors
Write-Output "--------- Check Windows Event Log ---------"
eventvwr /c:System
