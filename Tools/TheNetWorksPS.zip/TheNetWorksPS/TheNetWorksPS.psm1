# TheNetWorks PowerShell Script Module - to be reused by other TNW Scripts
# Copyright TheNetWorks LLC 2025

# ------------ Constants used in the API Access -------------
$tokenId = 'f8daa642e8cb49e9bbc9d0d1d60fff99'
$tokenSecret = '69fbd22852eb4989b67baf596bc4ee1ed966921b71354f329ea0f11ff496b604'
# Define all the main endpoints used in this code
$UrlDevices = 'https://thenetworksllc.pulseway.com/api/v3/devices'
$UrlNotifications= 'https://thenetworksllc.pulseway.com/api/v3/notifications'
$MaxRecs = 100

# ------------ Constants used in sending mail -------------
$DefMailServer = "smtp.office365.com"
$DefFromUser   = "info@thenetworks.us"
$DefToUser     = "mike@thenetworks.us"
$DefAppPW      = "ypbhwycvjpnqxczv"

function Set-Header () {

  # Initialize the auth and tokents info for headers
  $base64Encoded =   [System.Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes("$($tokenId):$($tokenSecret)"))

  $Headers=@{}
  $Headers.Add("Content-Type", "application/json")
  $Headers.Add("Accept", "*/*")
  $Headers.Add("Authorization", "Basic $($base64Encoded)")

  return $Headers
}

function Start-Notification($Headers, $InstId, $Title, $Message, $Priority) {
  $NotifId = 0

  # Create the RequestBody
  $ReqBody = '{"InstanceId":"'
  $ReqBody += $InstID
  $ReqBody += '","Title":"'
  $ReqBody += $Title
  $ReqBody += '","Message":"'
  $ReqBody += $Message
  $ReqBody += '","Priority":"'
  $ReqBody += $Priority
  $ReqBody += '"}'

  $UrlString = $UrlNotifications
  $NotifResp = Invoke-WebRequest -Uri $UrlString -Headers $Headers -Method POST -ContentType 'application/json' -Body "$ReqBody"

  if($NotifResp.StatusCode -ne "200") {
    return $NotifId }

  $RespJson = $NotifResp.Content | ConvertFrom-Json
  $NotifId = $RespJson.Data.NotificationId

  return $NotifId
}

function Get-AllDevices($Headers) {
  $UrlString = $UrlDevices
  $RecPointer = 0   # This should be incremented to march through entire task list

  $AllDevices = Invoke-WebRequest -Uri $UrlString ` -Headers $Headers ` -Method GET

  # Convert Stream to JSON Object
  $DevicesStruct = $AllDevices | ConvertFrom-Json
  $AllDevicesData = $DevicesStruct.data

  $NumDevices = $DevicesStruct.Meta.TotalCount
  # Calculate number of requests to make
  $NumRequests = [math]::truncate($NumDevices / $MaxRecs) + 1

  # If there are more than 100 (MaxRecs) tasks iterate until complete
  for($i = 1; $i -lt $NumRequests; $i++) {
    # Point to next batch of records
    $RecPointer += $MaxRecs
    $SkipString='?$skip=' + $RecPointer

    # Form the URL to skip to the next batch of records
    $UrlString = $UrlDevices + $SkipString

    $AllDevices = Invoke-WebRequest -Uri $UrlString ` -Headers $Headers ` -Method GET
    $DevicesStr = $AllDevices | ConvertFrom-Json

    # Accumlate responses into a single object to return
    $AllDevicesData += $DevicesStr.data
  }

  return $AllDevicesData
}

function Get-DeviceID($Headers, $DeviceName) {

  $DeviceId = 0
  $DeviceList = Get-AllDevices($Headers)
  foreach ($Device in $Devicelist) {
    if($Device.Name -ieq $DeviceName) {		# Permit case insensitive match
      $DeviceId = $Device.Identifier
      break
    }
  }
  return $DeviceId
}

function Get-DevDetails($Headers, $DeviceID) {
  $UrlString = $UrlDevices + $DeviceID
  $DevDetails = Invoke-WebRequest -Uri $UrlString ` -Headers $Headers ` -Method GET

  return $DevDetails
}

function Send-Mail ($Title, $BodyMsg) {		# Send a message & subject line

  $MailServer=$DefMailServer
  $ToUser = $DefToUser
  $FromUser = $DefFromUser		# Pick a non-admin user to just send mail
  $AppPW = $DefAppPW

  # Get the Credentials
  $PWord=ConvertTo-SecureString -String $AppPW -AsPlainText -Force
  $Cred = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $FromUser, $PWord

  # Now send the message
  Send-MailMessage -Body $BodyMsg -From $FromUser -SmtpServer $MailServer -Subject $Title -Credential $Cred -To $ToUser -UseSsl -Port 587
}

Export-ModuleMember -Function Set-Header, Start-Notification, Get-AllDevices, Get-DeviceID, Get-DevDetails, Send-Mail 
