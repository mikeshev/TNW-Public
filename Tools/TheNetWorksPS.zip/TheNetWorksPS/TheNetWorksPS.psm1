# TheNetWorks PowerShell Script Module - to be reused by other TNW Scripts
# Copyright TheNetWorks LLC 2025

# -------------- Pulseway API Related Functions -------------
# ------------ Constants used in the API Access -------------
$tokenId	= 'f8daa642e8cb49e9bbc9d0d1d60fff99'
$tokenSecret	= '69fbd22852eb4989b67baf596bc4ee1ed966921b71354f329ea0f11ff496b604'
# Define all the main endpoints used in this code
$UrlDevices	= 'https://thenetworksllc.pulseway.com/api/v3/devices'
$UrlDevices2	= 'https://thenetworksllc.pulseway.com/api/v3/devices/'
$UrlAssets	= 'https://thenetworksllc.pulseway.com/api/v3/assets/'
$UrlScripts     = 'https://thenetworksllc.pulseway.com/api/v3/automation/scripts/'
$UrlNotifications= 'https://thenetworksllc.pulseway.com/api/v3/notifications'
$MaxRecs	= 100
$EmailFieldID	= 18    # Field ID for Email Addr

function Set-Header () {

  # Initialize the auth and tokents info for headers
  $base64Encoded =   [System.Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes("$($tokenId):$($tokenSecret)"))

  $Headers=@{}
  $Headers.Add("Content-Type", "application/json")
  $Headers.Add("Accept", "*/*")
  $Headers.Add("Authorization", "Basic $($base64Encoded)")

  return $Headers
}

function Get-Api($UrlString, $Headers, $Method) {
  $RetVal = $null
  $RetVal = Invoke-WebRequest -Uri $UrlString -UseBasicParsing -Header $Headers -Method $Method

  return $RetVal
}

function Start-Notification($Headers, $InstId, $Title, $Message, $Priority) {
  $NotifId = 0

  # Create the RequestBody
  $ReqBody = '{"InstanceId":"'
  $ReqBody += $InstID
  $ReqBody += '","Title":"'
  $ReqBody += $Title
  $ReqBody += '","Message":"'
  $ReqBody += $Message
  $ReqBody += '","Priority":"'
  $ReqBody += $Priority
  $ReqBody += '"}'

  $UrlString = $UrlNotifications

  # Temp Hack to prevent nasty error message. Notification actually posted but
  # command returns error. So it is not currently possible to get NotifId.
  try {
    $NotifResp = Invoke-WebRequest -Uri $UrlString -UseBasicParsing -Headers $Headers -Method POST -ContentType 'application/json' -Body "$ReqBody" -ErrorAction Continue
    }
  catch {}

  if($NotifResp.StatusCode -ne "200") {
    return $NotifId }

  $RespJson = $NotifResp.Content | ConvertFrom-Json
  $NotifId = $RespJson.Data.NotificationId

  return $NotifId
}

function Get-AllDevices($Headers) {
  $UrlString = $UrlDevices
  $RecPointer = 0   # This should be incremented to march through entire task list

  $AllDevices = Get-Api $UrlString $Headers GET

  # Convert Stream to JSON Object
  $DevicesStruct = $AllDevices | ConvertFrom-Json
  $AllDevicesData = $DevicesStruct.data

  $NumDevices = $DevicesStruct.Meta.TotalCount
  # Calculate number of requests to make
  $NumRequests = [math]::truncate($NumDevices / $MaxRecs) + 1

  # If there are more than 100 (MaxRecs) tasks iterate until complete
  for($i = 1; $i -lt $NumRequests; $i++) {
    # Point to next batch of records
    $RecPointer += $MaxRecs
    $SkipString='?$skip=' + $RecPointer

    # Form the URL to skip to the next batch of records
    $UrlString = $UrlDevices + $SkipString

    $AllDevices = Get-Api $UrlString $Headers GET
    $DevicesStr = $AllDevices | ConvertFrom-Json

    # Accumlate responses into a single object to return
    $AllDevicesData += $DevicesStr.data
  }

  return $AllDevicesData
}

function Get-DeviceID($Headers, $DeviceName) {

  $DeviceId = 0
  $DeviceList = Get-AllDevices($Headers)
  foreach ($Device in $Devicelist) {
    if($Device.Name -ieq $DeviceName) {		# Permit case insensitive match
      $DeviceId = $Device.Identifier
      break
    }
  }
  return $DeviceId
}

function Get-DevDetails($Headers, $DeviceID) {
  $UrlString = $UrlDevices2 + $DeviceID
  $DevDetails = Get-Api $UrlString $Headers GET

  return $DevDetails
}

function Get-DevAssets($Headers, $DeviceID) {
  $UrlString = $UrlAssets + $DeviceID
  $DevAssets = Get-Api $UrlString $Headers GET

  return $DevAssets
}

function Get-MyDeviceId() {		# Get Device ID from Registry
  $DeviceIdKey = "HKLM:\SOFTWARE\MMSOFT Design\PC Monitor"
  $DeviceId = $null

  # Now check for registry key
  if(Test-Path -Path $DeviceIdKey) {
    $DeviceId = Get-ItemPropertyValue -Path $DeviceIdKey -Name "ComputerIdentifier"
  }  
  return $DeviceId
}

function Get-AllScripts($Headers) {
  # Note that the API returns only up to 100 objects at a time. Must read in chunks
  $RecPointer = 0	# Points to the next block to return
  $UrlString = $UrlScripts + '/'

  $AllScripts = Get-Api $UrlString $Headers GET
  $ScriptsList = $AllScripts | ConvertFrom-Json
  $AllScriptsData = $ScriptsList.data

  $NumScripts = $ScriptsList.Meta.TotalCount

  # Calculate number of requests to make
  $NumRequests = [math]::truncate($NumScripts / $MaxRecs) + 1

  # If there are more than 100 (MaxRecs) tasks iterate until complete
  for($i = 1; $i -lt $NumRequests; $i++) {
    # Point to next batch of records
    $RecPointer += $MaxRecs
    $SkipString='?$skip=' + $RecPointer

    # Form the URL to skip to the next batch of records
    $UrlString = $UrlScripts + $SkipString

    $AllScripts = Get-Api $UrlString $Headers GET
    $ScriptsList = $AllScripts | ConvertFrom-Json

    # Accumlate responses into a single object to return
    $AllScriptsData += $ScriptsList.data
  }
  return $AllScriptsData
}

# Given the ScriptName get the Id of the script
function Get-ScriptID($Headers, $ScriptName) {

  $ScriptId = 0
  $ScriptList = Get-AllScripts($Headers)
  foreach ($Script in $Scriptlist) {
    if($Script.Name -ieq $ScriptName) {		# permit case insensitive match
      $ScriptId = $Script.Id
      break
    }
  }

  return $ScriptId
}

# Run Script on a Single Device
function Invoke-ScriptDev($Headers, $ScriptID, $DeviceID) {

  # Build the Body of the Post message
  $RunScriptBody = '{"DeviceIdentifier":"' 
  $RunScriptBody += $DeviceID
  $RunScriptBody += '"}'

  $RunScriptUrl = $UrlScripts + $ScriptID + '/run'
  $ScriptResp = Invoke-WebRequest -Uri $RunScriptUrl -UseBasicParsing `
	-Headers $Headers `
	-Method POST `
	-ContentType 'application/json' `
	-Body "$RunScriptBody"

  if($ScriptResp -eq $null) {
    Write-Host "Script Execution Failed"
    exit -3}
  
  $ScriptExeIDStr = $ScriptResp.Content | ConvertFrom-Json
  $ScriptExeID = $ScriptExeIDStr.Data

  return $ScriptExeID.ExecutionId
}

# Get the output for this Script, Device and Execution Instance
# This has a built-in delay / polling for longer executing scripts. For long running
# scripts the state is set to "
function Get-ScriptOutput($Headers, $ScriptID, $DeviceID, $ExecutionID, $PollDelay) {

  # Valid State Values: Running, Failed, Stopped Successful
  $ScriptState = "Running"
  $GetResultsUrl = $UrlScripts + $ScriptID + "/device/" + $DeviceID + "/executions/" + $ExecutionID

  # Extra Delay before attempting Script Execution
  Start-Sleep $PollDelay

  # Poll the script until it is set to success
  while($ScriptState -eq "Running") {
    # Set the polling delay to $PollDelay
    Start-Sleep $PollDelay

    $ScriptResp = Invoke-WebRequest -Uri $GetResultsUrl -UseBasicParsing `
	-Headers $Headers `
	-Method GET `
	-ContentType 'application/json'

    $ScripOutputStr = $ScriptResp.Content | ConvertFrom-Json
    $ScriptState = $ScripOutputStr.Data.State
  }

  $ScriptOutput = $ScripOutputStr.Data.Output

  return $ScriptOutput
}

# --------------- Email Related Functions -----------------
# ------------ Constants used in sending mail -------------
$DefMailServer = "smtp.office365.com"
$DefFromUser   = "info@thenetworks.us"
$DefToUser     = "mike@thenetworks.us"
$DefAppPW      = "ypbhwycvjpnqxczv"

function Send-Mail ($ToUser, $Title, $BodyMsg) { # Send a message & subject line

  $MailServer=$DefMailServer
  $FromUser = $DefFromUser		# Pick a non-admin user to just send mail
  $AppPW = $DefAppPW

  # Get the Credentials
  $PWord=ConvertTo-SecureString -String $AppPW -AsPlainText -Force
  $Cred = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $FromUser, $PWord

  # Now send the message. Catch error messages
  Try {
    Send-MailMessage -Body $BodyMsg -From $FromUser -SmtpServer $MailServer -Subject $Title -Credential $Cred -To $ToUser -UseSsl -Port 587
    }
  Catch {
    Write-Host "Error Sending mail to $ToUser"
    return $false
  }
}

# Get UserEMail Custom Field defined on device
function Get-DevEmail($Headers, $DeviceID) {
  $EmailID = $EmailFieldID
  $UserEmail = "Uninitialized"
  $UrlString = $UrlDevices + "/"
  $UrlString = $UrlString + $DeviceID + "/customfields"
  $CustomFields = Get-Api $UrlString $Headers GET
  $CustomFieldsJson = $CustomFields.Content | ConvertFrom-Json
  $CustomFieldsData = $CustomFieldsJson.Data

  # Search for the Custom Field with the matching ID (EmailID)
  foreach($Field in $CustomFieldsData) {
    if($Field.Id -eq $EmailID) {
      $UserEmail = $Field.Value
      break }
  }
  return $UserEmail
}

function Get-ThisDevEmail ($Headers) {
  $DeviceId = Get-MyDeviceID
  $UserEmail = Get-DevEmail $Headers $DeviceId

  return $UserEmail
}

function Set-NotifyThisUser ($Header, $Device, $Title, $BodyMsg) {
  $Sent = $false

  # Get email address for THIS user
  $UserEmail = Get-DevEmail $Header $Device.Identifier
$UserEmail = "mike@thenetworks.us"	# <<< testing Hack
  Send-Mail $UserEmail $Title $BodyMsg

  $Sent = $true
  return $Sent
}

# --------------- Quarantine Related Functions ---------------
function Get-QuarantineCurrent {
  # Get Current items in Quarantine. 
  $Items=c:"\Program Files\Windows Defender\MpCmdRun.exe" -Restore -ListAll
  $LineCount=$Items.Count

  $ThreatStr="file:"
  $Matches= $Items -match $ThreatStr
  if($Matches -eq $false) { 
    $ItemCount = 0 }
  else {
    $ItemCount = $Matches.Count}

  Write-Output "--- $ItemCount Current Quarantine Items ---"

  # Output items if we have any
  for ($i = 2; $i -lt $LineCount; $i++) {
    # See if this is a ThreatName or file
    if($Items[$i].Contains("file")) {
      $OutStr =  "-- " + $Items[$i]
      Write-Output $OutStr }
    else {
      Write-Output $Items[$i] }
  }
}

function ExtractFileName ($Resource) {
  # Clear the resource prefix, usually "file:_"
  $FileName = $Resource -replace '.*:_', ''

  # Next check if this has webfile format. Truncate
  $FileName = $FileName -replace '\|.*', ''

  # Lastly check / remove -> construct in path
  $FileName = $FileName -replace '->.*', ''

return $FileName
}

function Get-CleaningAction ($CleanActionID) {

  # Filter CleaningActionID for serious conditions
  $CleaningActionStr=$null
  if($CleaningActionID     -eq 0) {$CleaningActionStr = "CleaningAction: Unknown,"}
  elseif($CleaningActionID -eq 1) {$CleaningActionStr = "CleaningAction: Clean,"}
  elseif($CleaningActionID -eq 2) {$CleaningActionStr = "CleaningAction: Quarantine,"}
  elseif($CleaningActionID -eq 3) {$CleaningActionStr = "CleaningAction: Remove,"}
  elseif($CleaningActionID -eq 4) {$CleaningActionStr = "CleaningAction: Allow,"}
  elseif($CleaningActionID -eq 5) {$CleaningActionStr = "CleaningAction: UserDefined,"}
  elseif($CleaningActionID -eq 6) {$CleaningActionStr = "CleaningAction: NoAction,"}
  elseif($CleaningActionID -eq 7) {$CleaningActionStr = "CleaningAction: Block,"}
  elseif($CleaningActionID -eq 8) {$CleaningActionStr = "CleaningAction: ManualStepsRequired,"}
  elseif($CleaningActionID -eq 9) {$CleaningActionStr = "CleaningAction: UnwantedApplications,"}

  return $CleaningActionStr
}

function Get-ThreatStatusStr ($ThreatStatusID) {

  # Filter ThreatStatusID serious conditions
  $ThreatStatusStr = $null
  if($ThreatStatusID -eq 0)       {$ThreatStatusStr = "ThreatStatus: Unknown"}
  elseif($ThreatStatusID -eq 1)   {$ThreatStatusStr = "ThreatStatus: Detected"}
  elseif($ThreatStatusID -eq 3)   {$ThreatStatusStr = "ThreatStatus: Quarantined"}
  elseif($ThreatStatusID -eq 4)   {$ThreatStatusStr = "ThreatStatus: Removed"}
  elseif($ThreatStatusID -eq 5)   {$ThreatStatusStr = "ThreatStatus: Threat Allowed"}
  elseif($ThreatStatusID -eq 6)   {$ThreatStatusStr = "ThreatStatus: Clean Failed"}
  elseif($ThreatStatusID -eq 102) {$ThreatStatusStr = "ThreatStatus: Quarantine Failed"}
  elseif($ThreatStatusID -eq 103) {$ThreatStatusStr = "ThreatStatus: Remove Failed"}
  elseif($ThreatStatusID -eq 104) {$ThreatStatusStr = "ThreatStatus: Allow Failed"}
  elseif($ThreatStatusID -eq 105) {$ThreatStatusStr = "ThreatStatus: Abandoned"}
  elseif($ThreatStatusID -eq 106) {$ThreatStatusStr = "ThreatStatus: Unable to Block"}
  elseif($ThreatStatusID -eq 107) {$ThreatStatusStr = "ThreatStatus: Blocked Failed"}
   
  return $ThreatStatusStr
}

function Get-DetectionSourceStr ($DetectionSourceTypeID) {
  # Assign DetectionSourceTypeID meaning
  $DetectionSourceStr = $null
  if($DetectionSourceTypeID -eq 0)     {$DetectionSourceStr = "DetectionSource: Unknown,"}
  elseif($DetectionSourceTypeID -eq 1) {$DetectionSourceStr = "DetectionSource: User,"}
  elseif($DetectionSourceTypeID -eq 2) {$DetectionSourceStr = "DetectionSource: System,"}
  elseif($DetectionSourceTypeID -eq 3) {$DetectionSourceStr = "DetectionSource: Real-time,"}
  elseif($DetectionSourceTypeID -eq 4) {$DetectionSourceStr = "DetectionSource: AttachmentsDownloadsOutlook,"}
  elseif($DetectionSourceTypeID -eq 5) {$DetectionSourceStr = "DetectionSource: NetworkInspection,"}
  elseif($DetectionSourceTypeID -eq 7) {$DetectionSourceStr = "DetectionSource: EarlyLaunchAntiMalware,"}
  elseif($DetectionSourceTypeID -eq 8) {$DetectionSourceStr = "DetectionSource: LocalAttestation,"}
  elseif($DetectionSourceTypeID -eq 9) {$DetectionSourceStr = "DetectionSource: RemoteAttestation,"}
  
  return $DetectionSourceStr
}

function Check-File ($FilePath) {
  $Present = $false

  if(Test-Path -Path $FilePath -PathType Leaf) {
    $Present = $true
  }
  
  return $Present
}

function Get-Quarantine ($Threat) {

  $CleaningActionID = $Threat.CleaningActionID
  $ThreatStatusID   = $Threat.ThreatStatusID
  $DetectionSourceTypeID   = $Threat.DetectionSourceTypeID
    
  $Resources = $Threat.Resources
    
  $CleaningActionStr = Get-CleaningAction $CleaningActionID
    
  $ThreatStatusStr = Get-ThreatStatusStr $ThreatStatusID

  $DetectionSourceStr = Get-DetectionSourceStr $DetectionSourceTypeID

  if($CleaningActionID -ne $null -or $ThreatStatusID -ne $null) {
    Write-Host ""
    Write-Host "Malware Warning: " $DetectionSourceStr $CleaningActionStr $ThreatStatusStr

    # Iterate through all resource to ensure they are dealt with
    foreach ($Resource in $Resources) {
      $QuarantineFile = ExtractFileName $Resource

      # Check to see if the file is still present
      $Present = Check-File $QuarantineFile
      if($Present -ne $true) {
        Write-Host "Deleted / Quarantined: " $QuarantineFile }
      else {
        Write-Host "Still Present: " $QuarantineFile }
      }
    }

    if($Verbose -eq $true) {
      # Write out the entire record
      Write-Host ($Threat | Format-List | Out-String)}
}

Export-ModuleMember -Function Set-Header, Get-Api, Start-Notification, Get-AllDevices, Get-DeviceID, Get-DevDetails, Get-DevAssets, Get-ScriptID, Invoke-ScriptDev, Get-ScriptOutput, Send-Mail, Get-DevEmail, Get-ThisDevEmail, Get-MyDeviceId, Set-NotifyThisUser, Get-Quarantine, Get-QuarantineCurrent 