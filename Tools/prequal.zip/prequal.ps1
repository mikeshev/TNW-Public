# TheNetWorks LLC - Pre Qualification script
# Copyright 2023 TheNetWorks LLC

# Make sure the disk itself is Sound
chkdsk /scan c:

# Make sure the Image is Sound
dism /online /cleanup-image /ScanHealth
sfc /scannow

# Make sure updates have been happening
get-wmiobject -class win32_quickfixengineering 

# or alternately but format above is cleaner
# wmic qfe list

# Check Quarantine files
c:\"Program Files\Windows Defender"\MpCmdRun.exe -restore -listall

# Lastly check the Event Log for recent Critical Errors
eventvwr /l:"\Windows\System32\winevt\Logs\System.evtx"
